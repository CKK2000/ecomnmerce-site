# ecommerce
A responsive e-commerce site template using JavaScript, HTML, CSS.
Pages: index.html gives an overview of the site, and has links to:
#products.html, where all products are listed
#prod-details.html, where details of an individual product are provided
#cart.html (through the logo of a cart), where an overview of a customer's cart has been shown
#account.html, where process of sign up and login for a new user has been shown
All pages have also been interlinked.
